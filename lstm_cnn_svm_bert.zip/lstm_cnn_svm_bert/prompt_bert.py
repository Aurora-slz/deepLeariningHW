from transformers import AutoTokenizer, BertTokenizer, AdamW, get_cosine_schedule_with_warmup
from torch.utils.data import DataLoader
import trainer
from openprompt.plms import load_plm
from openprompt.prompts import ManualTemplate
from openprompt import PromptDataLoader
from openprompt.prompts import SoftVerbalizer
from openprompt.prompts import ManualVerbalizer
from openprompt import PromptForClassification
from openprompt.data_utils import InputExample
import torch
import os
import pandas as pd
import numpy as np

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EPOCHS = 100
classes = ['negative','positive']

def load_data(file):
    D = []
    cnt = 1
    with open(file, 'r', encoding='utf-8') as f:
        text = ""
        label = ""
        for line in f:
            cnt = cnt + 1
            if(cnt % 2 == 0):
                text = line
               # print("text: ", text)
                text = text.rstrip()
            else:
                label = line
               # print("label: ", label)
                label = label.rstrip()
                label = int(label)
                D.append((text, label))
    data = pd.DataFrame(columns=['text','label'], data=D)
    print(data.head(5))
    return data
print(os.getcwd() + "/data/sum_train.txt")
train_data = load_data(os.getcwd() + "/data/train.txt")
test_data = load_data(os.getcwd() + "/data/test.txt")

for i in range(len(train_data)):
    if train_data['label'][i] == 0:
        train_data['text'][i] = InputExample(guid=0,text_a=train_data['text'][i])
    else:
        train_data['text'][i] = InputExample(guid=1,text_a=train_data['text'][i])

for i in range(len(test_data)):
    if test_data['label'][i] == 0:
        test_data.append(InputExample(guid=0,text_a=test_data['text'][i]))
    else:
        test_data.append(InputExample(guid=1,text_a=test_data['text'][i]))

plm, tokenizer, model_config, WrapperClass = load_plm("bert", "bert-base-cased")#读取预训练模型
#这一行是关键代码，写模版
mytemplate = ManualTemplate(tokenizer=tokenizer,
                            text='{"placeholder":"text_a"} Is it a contrastive sentence? {"mask"}')

train_loader = PromptDataLoader(dataset=train_data, template=mytemplate, tokenizer=tokenizer,
    tokenizer_wrapper_class=WrapperClass, max_seq_length=256,
    batch_size=8,shuffle=True)

test_loader = PromptDataLoader(dataset=test_data, template=mytemplate, tokenizer=tokenizer,
    tokenizer_wrapper_class=WrapperClass, max_seq_length=256,
    batch_size=8,shuffle=True)


promptVerbalizer = ManualVerbalizer(
        classes=classes,
        label_words={
            "negative":["no"],
            "positive":["yes"]
        },
        tokenizer = tokenizer
)

prompt_model = PromptForClassification(plm=plm, template=mytemplate, verbalizer=promptVerbalizer)
optimizer = AdamW(prompt_model.parameters(), lr=2e-5, weight_decay=1e-4)
scheduler = get_cosine_schedule_with_warmup(optimizer, num_warmup_steps=len(train_loader),
                                            num_training_steps=EPOCHS * len(train_loader))

trainer.train(prompt_model, train_loader, test_loader, tokenizer, optimizer, scheduler, DEVICE, EPOCHS)
