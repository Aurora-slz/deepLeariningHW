import torch
from torch import nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim  # 导入上面的torch.nn包之后还需导入torch.optim包
from transformers import AutoTokenizer, AutoConfig, AutoModel

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class LSTMTagger(nn.Module):

    def __init__(self, embedding_dim, hidden_dim, targset_size, batch_size, vocab_size=30522):
        super(LSTMTagger, self).__init__()
        self.targset_size = targset_size  # 2
        self.hidden_dim = hidden_dim  # 64
        self.batch_size = batch_size  # 4
        self.embedding_dim = embedding_dim  # 5
        self.word_embeddings = nn.Embedding(vocab_size, embedding_dim)
        print("embedding ** ")
        # LSTM以word_embeddings作为输入, 输出维度为 hidden_dim 的隐藏状态值
        self.lstm = nn.LSTM(self.embedding_dim, self.hidden_dim, num_layers=2)

        self.drop = nn.Dropout(p=0.5)

        self.classifier = nn.Sequential(nn.Dropout(0.5),
                                        nn.Linear(hidden_dim, 1),
                                        nn.Sigmoid())

        # 线性层将隐藏状态空间映射到标注空间
        # self.hidden2tag = nn.Linear(self.hidden_dim, self.targset_size)
        self.hidden = self.init_hidden()

    def init_hidden(self):
        # 各个维度的含义是 (num_layers*num_directions, batch_size, hidden_dim)
        return (torch.zeros(2, self.batch_size, self.hidden_dim).to(DEVICE),  # h_0
                torch.zeros(2, self.batch_size, self.hidden_dim).to(DEVICE))  # c_0

    # input: seq_len, batch_size, word_embedding
    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        # print(input_ids.shape)
        embeds = self.word_embeddings(input_ids)
        # print("self.hidden: ", self.hidden)

        # lstm_out: batch_size, seq_len, hidden_size
        lstm_out, (last_hidden, cn) = self.lstm(embeds.view(-1, self.batch_size, self.embedding_dim), self.hidden)
        # print(len(lstm_out))
        # print(lstm_out.shape)
        # print(last_hidden.shape)
        # lstm_out = lstm_out.view(-1, input_ids.shape[0], self.hidden_dim)
        f_last_hidden = lstm_out[-1, :, :]
        # print("f_last_hidden.shape: ", f_last_hidden.shape)

        f_last_hidden = self.drop(f_last_hidden)
        # tag_space = self.hidden2tag(f_last_hidden.view(-1, self.hidden_dim))
        # tag_scores = F.log_softmax(tag_space, dim=1)
        x = self.classifier(f_last_hidden)
        return x