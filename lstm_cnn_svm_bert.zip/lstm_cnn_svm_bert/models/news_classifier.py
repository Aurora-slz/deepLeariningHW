from transformers import BertModel, BertConfig, AutoTokenizer, AutoConfig, AutoModel
from torch import nn


class NewsClassifier(nn.Module):
    def __init__(self, bert_path, num_labels):
        super(NewsClassifier, self).__init__()
        self.config = AutoConfig.from_pretrained(bert_path)
        self.bert = AutoModel.from_pretrained(bert_path)
        for param in self.bert.parameters():
            param.requires_grad = True
        self.fc = nn.Linear(self.config.hidden_size, num_labels)

    #def forward(self, input_ids, attention_mask, token_type_ids):
    def forward(self, input_ids, attention_mask=None , token_type_ids=None):
        #outputs = self.bert(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
        outputs = self.bert(input_ids, attention_mask, token_type_ids)
        out_pool = outputs[1]
        return self.fc(out_pool)

