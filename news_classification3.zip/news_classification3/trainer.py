import time

import torch
from sklearn.metrics import accuracy_score
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import f1_score

MAX_LENGTH = 64


# 将DataFrame划分为训练集和验证集
def train_val_split(dataset, frac=0.8, random_state=None):
    train_set = dataset.sample(frac=frac, random_state=random_state, axis=0)
    val_set = dataset[~dataset.index.isin(train_set.index)]
    return train_set.reset_index(), val_set.reset_index()


# 训练并验证模型
def train(model, train_loader, valid_loader, tokenizer, optimizer, scheduler, device, epoch_num):
    criterion = torch.nn.CrossEntropyLoss()
    model.train()
    max_f1 = 0
    print("***** Training *****")
    for epoch in range(epoch_num):
        start = time.time()
        epoch_loss = 0
        train_labels_true, train_labels_pred = [], []
        for i, batch in enumerate(train_loader):
            label = batch['label']
            text = batch['text']
            tokenized_text = tokenizer(text, max_length=MAX_LENGTH, truncation=True,
                                       padding='max_length', return_tensors="pt")

            #input_ids = tokenized_text['input_ids']
            #token_type_ids = tokenized_text["token_type_ids"]
            #attention_mask = tokenized_text["attention_mask"]
            #outputs = model(input_ids.to(device), token_type_ids.to(device), attention_mask.to(device))

            outputs = model(**tokenized_text.to(device))
            loss = criterion(outputs, label.to(device))
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            scheduler.step()
            epoch_loss += loss.item()

            train_labels_pred.extend(torch.argmax(outputs, dim=1).detach().cpu().numpy().tolist())
            train_labels_true.extend(label.squeeze().cpu().numpy().tolist())

            # log
            if (i + 1) % (len(train_loader) // 20) == 0:
                print("Step {:04d}/{:04d}  Loss: {:.4f}  Time: {}s:"
                      .format((i + 1), len(train_loader), epoch_loss / (i + 1), time.time() - start))
        train_accuracy = accuracy_score(train_labels_true, train_labels_pred)
        train_f1 = f1_score(train_labels_true, train_labels_pred)
        print("train Accuracy: {}  train F1: {}".format(train_accuracy, train_f1))

        accuracy,f1 = evaluate(model, valid_loader, tokenizer, device)
        print("test Accuracy: {}  test F1: {}".format(accuracy, f1))
        print("best f1: {}".format(max_f1))
        if(f1 > max_f1):
            max_f1 = f1
            torch.save(model, 'models/best_cls_model.pkl')

# 使用验证集评估模型
def evaluate(model, data_loader, tokenizer, device):
    model.eval()
    # 存放正确标签和预测标签
    labels_true, labels_pred = [], []
    with torch.no_grad():
        for i, batch in (enumerate(data_loader)):
            text = batch['text']
            labels = batch['label']
            tokenized_text = tokenizer(text, max_length=MAX_LENGTH, truncation=True,
                                       padding='max_length', return_tensors="pt")
            outputs = model(**tokenized_text.to(device))
            labels_pred.extend(torch.argmax(outputs, dim=1).detach().cpu().numpy().tolist())
            labels_true.extend(labels.squeeze().cpu().numpy().tolist())

    accuracy = accuracy_score(labels_true, labels_pred)
    f1 = f1_score(labels_true, labels_pred)
    return accuracy, f1
