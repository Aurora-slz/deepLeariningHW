import torch
from torch import nn
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim#导入上面的torch.nn包之后还需导入torch.optim包
from transformers import AutoTokenizer, AutoConfig, AutoModel

cuda = torch.device('cuda')
class LSTMTagger(nn.Module):

    def __init__(self, bert_path, embedding_dim, hidden_dim, targset_size, batch_size, vocab_size=512):
        super(LSTMTagger, self).__init__()
        self.config = AutoConfig.from_pretrained(bert_path)
        self.targset_size = targset_size
        self.hidden_dim = hidden_dim
        self.batch_size = batch_size
        self.embedding_dim =  embedding_dim
        self.word_embeddings = nn.Embedding(vocab_size, embedding_dim)
        print("embedding ** ")
        # LSTM以word_embeddings作为输入, 输出维度为 hidden_dim 的隐藏状态值
        self.lstm = nn.LSTM(self.embedding_dim, self.hidden_dim // 2, num_layers=2, bidirectional=True)

        # 线性层将隐藏状态空间映射到标注空间
        self.hidden2tag = nn.Linear(self.hidden_dim, self.targset_size)
        self.hidden = self.init_hidden()

    def init_hidden(self):
        # 各个维度的含义是 (num_layers*num_directions, batch_size, hidden_dim)
        return (torch.zeros(2 * 2, self.batch_size, self.hidden_dim // 2).cuda(), # h_0
                torch.zeros(2 * 2, self.batch_size, self.hidden_dim // 2).cuda()) # c_0

    def forward(self, sentence):
        batch_size = 1
        hidden_dim = 384
        embedding_dim = 10
        embeds = self.word_embeddings(sentence).cuda()
       # print('embeds_size: ', embeds.shape())
        lstm_out, self.hidden = self.lstm(
            embeds.view(-1, batch_size, embedding_dim), self.hidden)
        tag_space = self.hidden2tag(lstm_out.view(-1, self.hidden_dim))
        tag_scores = F.log_softmax(tag_space, dim=1)
        return tag_scores