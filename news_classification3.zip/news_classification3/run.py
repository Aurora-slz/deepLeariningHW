import pandas as pd
import torch
from transformers import AutoTokenizer, BertTokenizer, AdamW, get_cosine_schedule_with_warmup
from torch.utils.data import DataLoader
import trainer
from utils.news_set import NewsSet
from models.news_classifier import NewsClassifier
import os
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH_SIZE = 4


def load_data(file):
    D = []
    cnt = 1
    with open(file, 'r', encoding='utf-8') as f:
        text = ""
        label = ""
        for line in f:
            cnt = cnt + 1
            if(cnt % 2 == 0):
                text = line
               # print("text: ", text)
                text = text.rstrip()
            else:
                label = line
               # print("label: ", label)
                label = label.rstrip()
                label = int(label)
                D.append((text, label))
    data = pd.DataFrame(columns=['text','label'], data=D)
    print(data.head(5))
    return data
print(os.getcwd() + "/data/sum_train.txt")
train_data = load_data(os.getcwd() + "/data/sum_train.txt")
test_data = load_data(os.getcwd() + "/data/sum_test.txt")

# "bert-base-uncased"
# "roberta-base"
# "xlnet-base-cased"
bert_path = "roberta-base"
tokenizer = AutoTokenizer.from_pretrained(bert_path)
model = NewsClassifier(bert_path, 2).to(DEVICE)

EPOCHS = 100
#train_set, val_set = trainer.train_val_split(data_set)
train_loader = DataLoader(NewsSet(train_data), batch_size=BATCH_SIZE, shuffle=True)
test_loader = DataLoader(NewsSet(test_data), batch_size=BATCH_SIZE, shuffle=True)

# 输出train_loader的batch数量
print(len(train_loader))
optimizer = AdamW(model.parameters(), lr=2e-5, weight_decay=1e-4)
scheduler = get_cosine_schedule_with_warmup(optimizer, num_warmup_steps=len(train_loader),
                                            num_training_steps=EPOCHS * len(train_loader))

trainer.train(model, train_loader, test_loader, tokenizer, optimizer, scheduler, DEVICE, EPOCHS)
torch.save(model, 'models/cls_model.pkl')
