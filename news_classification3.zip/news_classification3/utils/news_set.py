from torch.utils.data import Dataset


class NewsSet(Dataset):

    def __init__(self, dataset_df):
        self.dataset = dataset_df

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, item):
        text = self.dataset.loc[item, "text"]
        label = self.dataset.loc[item, "label"]
        return {"text": text, "label": label}
